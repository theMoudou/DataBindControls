﻿using DeliciousMap.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DeliciousMap.API
{
    /// <summary>
    /// FoodAPIHandler 的摘要描述
    /// </summary>
    public class FoodAPIHandler : IHttpHandler
    {
        private List<MapContent> _list = new List<MapContent>();



        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "application/json";
            context.Response.Write("Hello World");
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}